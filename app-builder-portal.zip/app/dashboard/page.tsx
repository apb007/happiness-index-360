"use client"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

export default function DashboardPage() {
  const router = useRouter()
  const supabase = createClient()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const determineRole = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const role = user.user_metadata?.role || "student"

      // Route to appropriate dashboard
      switch (role) {
        case "teacher":
          router.push("/dashboard/teacher")
          break
        case "principal":
          router.push("/dashboard/principal")
          break
        case "admin":
          router.push("/dashboard/admin")
          break
        case "student":
        default:
          router.push("/dashboard/student")
          break
      }
    }

    determineRole()
  }, [router, supabase])

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center space-y-3">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
        <p className="text-muted-foreground">Loading your dashboard...</p>
      </div>
    </div>
  )
}
