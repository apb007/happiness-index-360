"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface Assessment {
  id: string
  score: number
  risk_level: string
  created_at: string
}

export default function HistoryPage() {
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchAssessments = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        const { data, error } = await supabase
          .from("assessments")
          .select("id, score, risk_level, created_at")
          .eq("student_id", user.id)
          .order("created_at", { ascending: false })

        if (error) throw error
        setAssessments(data || [])
      } catch (error) {
        console.error("Error fetching assessments:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAssessments()
  }, [router, supabase])

  const chartData = assessments
    .slice()
    .reverse()
    .map((a) => ({
      date: new Date(a.created_at).toLocaleDateString(),
      score: Math.round(a.score),
      fullDate: a.created_at,
    }))

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "text-green-600"
      case "moderate":
        return "text-yellow-600"
      case "high":
        return "text-orange-600"
      case "critical":
        return "text-red-600"
      default:
        return "text-foreground"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Assessment History</h1>
        <p className="text-muted-foreground">Track your mental health over time</p>
      </div>

      {assessments.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground mb-4">You haven't completed any assessments yet.</p>
            <a href="/dashboard/student" className="text-primary hover:underline font-medium">
              Take your first assessment →
            </a>
          </CardContent>
        </Card>
      ) : (
        <>
          {chartData.length > 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Score Trend</CardTitle>
                <CardDescription>Your assessment scores over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="score" stroke="#0891b2" name="Score (%)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>All Assessments</CardTitle>
              <CardDescription>Your complete assessment history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {assessments.map((assessment) => (
                  <div
                    key={assessment.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-secondary/50 transition"
                  >
                    <div className="space-y-1">
                      <p className="font-medium">
                        {new Date(assessment.created_at).toLocaleDateString()} at{" "}
                        {new Date(assessment.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                      <p className="text-sm text-muted-foreground capitalize">{assessment.risk_level} risk</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-2xl font-bold ${getRiskColor(assessment.risk_level)}`}>
                        {Math.round(assessment.score)}%
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
