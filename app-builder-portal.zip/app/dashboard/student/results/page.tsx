"use client"

import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { RiskGauge } from "@/components/risk-gauge"
import { getScoreAnalysis } from "@/lib/scoring"

export default function ResultsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const score = Number.parseFloat(searchParams.get("score") || "0")
  const risk = searchParams.get("risk") as "low" | "moderate" | "high" | "critical"
  const [user, setUser] = useState<any>(null)

  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login")
      } else {
        setUser(user)
      }
    }
    checkAuth()
  }, [router, supabase])

  const getRiskInfo = () => {
    switch (risk) {
      case "low":
        return {
          title: "Excellent Happiness Index!",
          description: getScoreAnalysis(score),
          color: "text-green-600",
          bgColor: "bg-green-50 dark:bg-green-950",
          borderColor: "border-green-200 dark:border-green-800",
          resources: [
            "Continue maintaining healthy sleep and exercise habits",
            "Stay connected with friends and family",
            "Keep practicing your stress management techniques",
            "Support others who may be struggling",
          ],
        }
      case "moderate":
        return {
          title: "Room for Improvement",
          description: getScoreAnalysis(score),
          color: "text-yellow-600",
          bgColor: "bg-yellow-50 dark:bg-yellow-950",
          borderColor: "border-yellow-200 dark:border-yellow-800",
          resources: [
            "Talk to a school counselor about specific concerns",
            "Practice relaxation techniques daily",
            "Maintain regular sleep and exercise schedules",
            "Reach out to trusted friends or family",
            "Identify one area to focus on for improvement",
          ],
        }
      case "high":
        return {
          title: "Support is Important",
          description: getScoreAnalysis(score),
          color: "text-orange-600",
          bgColor: "bg-orange-50 dark:bg-orange-950",
          borderColor: "border-orange-200 dark:border-orange-800",
          resources: [
            "Schedule a meeting with your school counselor today",
            "Crisis Text Line: Text HOME to 741741",
            "Talk to a trusted adult (parent, teacher, counselor)",
            "National Suicide Prevention Lifeline: 988",
            "Create a self-care plan with your counselor",
          ],
        }
      case "critical":
        return {
          title: "Immediate Support Needed",
          description: getScoreAnalysis(score),
          color: "text-red-600",
          bgColor: "bg-red-50 dark:bg-red-950",
          borderColor: "border-red-200 dark:border-red-800",
          resources: [
            "Call 911 if you're in immediate danger",
            "National Suicide Prevention Lifeline: 988 (call or text)",
            "Crisis Text Line: Text HOME to 741741",
            "Go to your nearest emergency room",
            "Call your parent/guardian immediately",
          ],
        }
      default:
        return {
          title: "Assessment Complete",
          description: "Thank you for completing the assessment.",
          color: "text-foreground",
          bgColor: "bg-secondary",
          borderColor: "border-border",
          resources: [],
        }
    }
  }

  const riskInfo = getRiskInfo()

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Happiness Index 360° Results</h1>
        <p className="text-muted-foreground">Your personalized happiness assessment score</p>
      </div>

      <Card className={`border-2 ${riskInfo.borderColor}`}>
        <CardContent className={`pt-8 ${riskInfo.bgColor}`}>
          <div className="flex items-center justify-center gap-8 flex-col sm:flex-row">
            <RiskGauge score={score} riskLevel={risk} size="lg" />
            <div className="text-center sm:text-left">
              <h2 className={`text-2xl font-bold ${riskInfo.color} mb-2`}>{riskInfo.title}</h2>
              <p className="text-foreground max-w-md">{riskInfo.description}</p>
              <p className="text-sm text-muted-foreground mt-3 font-semibold">Score: {score.toFixed(1)}/100</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recommended Next Steps</CardTitle>
          <CardDescription>Actions to support your happiness and wellbeing</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {riskInfo.resources.map((resource, index) => (
              <li key={index} className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-sm font-medium">
                  {index + 1}
                </div>
                <span className="text-foreground pt-0.5">{resource}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Important Resources</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="font-semibold text-foreground">National Suicide Prevention Lifeline</p>
            <p className="text-muted-foreground">988 (Available 24/7) • Call or Text</p>
          </div>
          <div>
            <p className="font-semibold text-foreground">Crisis Text Line</p>
            <p className="text-muted-foreground">Text HOME to 741741</p>
          </div>
          <div>
            <p className="font-semibold text-foreground">School Counselor</p>
            <p className="text-muted-foreground">Available during school hours</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-center pt-4">
        <Button variant="outline" onClick={() => router.push("/dashboard/student")}>
          Take Assessment Again
        </Button>
        <Button onClick={() => router.push("/dashboard/student/history")}>View History</Button>
      </div>
    </div>
  )
}
