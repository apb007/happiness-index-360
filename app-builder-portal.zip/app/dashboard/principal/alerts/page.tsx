"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface Alert {
  id: string
  student_id: string
  student_name: string
  alert_type: string
  message: string
  is_resolved: boolean
  created_at: string
}

export default function PrincipalAlertsPage() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        const schoolId = user.user_metadata?.school_id

        // Fetch all active alerts for the school
        const { data: alertsData } = await supabase
          .from("alerts")
          .select("id, student_id, alert_type, message, is_resolved, created_at")
          .eq("school_id", schoolId || "")
          .eq("is_resolved", false)
          .order("created_at", { ascending: false })

        if (!alertsData) {
          setAlerts([])
          setIsLoading(false)
          return
        }

        // Fetch student names
        const studentIds = alertsData.map((a) => a.student_id)
        const { data: students } = await supabase
          .from("profiles")
          .select("id, first_name, last_name")
          .in("id", studentIds)

        const studentMap = new Map(students?.map((s) => [s.id, `${s.first_name} ${s.last_name}`]) || [])

        const alertsWithNames = alertsData.map((alert) => ({
          ...alert,
          student_name: studentMap.get(alert.student_id) || "Unknown",
        }))

        setAlerts(alertsWithNames)
      } catch (error) {
        console.error("Error fetching alerts:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAlerts()
  }, [router, supabase])

  const handleResolveAlert = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from("alerts")
        .update({ is_resolved: true, resolved_at: new Date() })
        .eq("id", alertId)

      if (error) throw error
      setAlerts(alerts.filter((a) => a.id !== alertId))
    } catch (error) {
      console.error("Error resolving alert:", error)
    }
  }

  const getAlertBadgeColor = (type: string) => {
    switch (type) {
      case "critical":
        return "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-400"
      case "high_risk":
        return "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-400"
      case "moderate_risk":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-400"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-400"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Alerts</h1>
        <p className="text-muted-foreground">School-wide alerts for students needing support</p>
      </div>

      {alerts.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground">No active alerts. Great news for your school!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => (
            <Card key={alert.id} className="border-l-4 border-l-orange-500">
              <CardContent className="pt-6 flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold text-foreground">{alert.student_name}</h3>
                    <Badge className={getAlertBadgeColor(alert.alert_type)}>
                      {alert.alert_type.replace(/_/g, " ").toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{alert.message}</p>
                  <p className="text-xs text-muted-foreground">{new Date(alert.created_at).toLocaleDateString()}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => handleResolveAlert(alert.id)}>
                  Resolve
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
