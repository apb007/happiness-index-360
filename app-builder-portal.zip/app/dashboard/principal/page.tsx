"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from "recharts"
import { Button } from "@/components/ui/button"

interface DashboardStats {
  totalStudents: number
  totalClasses: number
  totalAssessments: number
  schoolAverageScore: number
  criticalRiskCount: number
  highRiskCount: number
  moderateRiskCount: number
  lowRiskCount: number
  riskDistribution: Array<{ name: string; value: number; fill: string }>
  classBreakdown: Array<{ name: string; average: number; assessments: number }>
  riskLevelCounts: Record<string, number>
}

export default function PrincipalDashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    totalClasses: 0,
    totalAssessments: 0,
    schoolAverageScore: 0,
    criticalRiskCount: 0,
    highRiskCount: 0,
    moderateRiskCount: 0,
    lowRiskCount: 0,
    riskDistribution: [],
    classBreakdown: [],
    riskLevelCounts: {},
  })
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        const schoolId = user.user_metadata?.school_id

        // Fetch total classes
        const { data: classesData } = await supabase
          .from("classes")
          .select("id, name")
          .eq("school_id", schoolId || "")

        // Fetch all assessments with scaled scores
        const { data: assessments } = await supabase
          .from("assessments")
          .select("risk_level, score, student_id, created_at")
          .eq("school_id", schoolId || "")

        // Get unique students
        const uniqueStudents = [...new Set(assessments?.map((a) => a.student_id) || [])]

        // Count risk levels
        const riskLevelCounts: Record<string, number> = {
          critical: 0,
          high: 0,
          moderate: 0,
          low: 0,
        }

        let totalScore = 0
        assessments?.forEach((a) => {
          if (a.risk_level) {
            riskLevelCounts[a.risk_level]++
          }
          totalScore += a.score || 0
        })

        const schoolAverageScore = assessments?.length ? Math.round((totalScore / assessments.length) * 10) / 10 : 0

        const classBreakdown = await Promise.all(
          (classesData || []).map(async (cls) => {
            const { data: classStudents } = await supabase
              .from("class_students")
              .select("student_id")
              .eq("class_id", cls.id)

            const classAssessments =
              assessments?.filter((a) => classStudents?.map((cs) => cs.student_id).includes(a.student_id)) || []

            const classAverageScore = classAssessments.length
              ? Math.round(
                  (classAssessments.reduce((sum, a) => sum + (a.score || 0), 0) / classAssessments.length) * 10,
                ) / 10
              : 0

            return {
              name: cls.name,
              average: classAverageScore,
              assessments: classAssessments.length,
            }
          }),
        )

        const riskDistribution = [
          { name: "Critical", value: riskLevelCounts.critical, fill: "#dc2626" },
          { name: "High", value: riskLevelCounts.high, fill: "#f97316" },
          { name: "Moderate", value: riskLevelCounts.moderate, fill: "#eab308" },
          { name: "Low", value: riskLevelCounts.low, fill: "#16a34a" },
        ]

        setStats({
          totalStudents: uniqueStudents.length,
          totalClasses: classesData?.length || 0,
          totalAssessments: assessments?.length || 0,
          schoolAverageScore,
          criticalRiskCount: riskLevelCounts.critical,
          highRiskCount: riskLevelCounts.high,
          moderateRiskCount: riskLevelCounts.moderate,
          lowRiskCount: riskLevelCounts.low,
          riskDistribution,
          classBreakdown,
          riskLevelCounts,
        })
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [router, supabase])

  const handleExportCSV = async () => {
    try {
      const response = await fetch("/api/export/assessments")
      if (!response.ok) throw new Error("Export failed")

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `happiness-index-report-${new Date().toISOString().slice(0, 10)}.csv`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Error exporting CSV:", error)
      alert("Failed to export data. Please try again.")
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Happiness Index 360° - School Overview</h1>
        <p className="text-muted-foreground">Mental health metrics and trends for your school</p>
      </div>

      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">School Average</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{stats.schoolAverageScore}</div>
            <p className="text-xs text-muted-foreground mt-1">Out of 100</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{stats.totalStudents}</div>
            <p className="text-xs text-muted-foreground mt-1">Across all classes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Classes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{stats.totalClasses}</div>
            <p className="text-xs text-muted-foreground mt-1">Active classes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Assessments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{stats.totalAssessments}</div>
            <p className="text-xs text-muted-foreground mt-1">Completed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">At Risk</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{stats.criticalRiskCount + stats.highRiskCount}</div>
            <p className="text-xs text-muted-foreground mt-1">Needing support</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Risk Level Distribution</CardTitle>
            <CardDescription>Breakdown of student risk assessment results</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stats.riskDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {stats.riskDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Risk Level Summary</CardTitle>
            <CardDescription>Count of students by risk category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { level: "Critical", count: stats.criticalRiskCount, color: "bg-red-100 dark:bg-red-950" },
                { level: "High", count: stats.highRiskCount, color: "bg-orange-100 dark:bg-orange-950" },
                { level: "Moderate", count: stats.moderateRiskCount, color: "bg-yellow-100 dark:bg-yellow-950" },
                { level: "Low", count: stats.lowRiskCount, color: "bg-green-100 dark:bg-green-950" },
              ].map((item) => (
                <div key={item.level} className={`p-3 rounded-lg ${item.color}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{item.level} Risk</span>
                    <span className="text-2xl font-bold">{item.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {stats.classBreakdown.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Class Average Happiness Index</CardTitle>
            <CardDescription>Happiness Index score by class</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats.classBreakdown}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `${value.toFixed(1)}/100`} />
                <Legend />
                <Bar dataKey="average" fill="#0891b2" name="Average Score" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Data Export</CardTitle>
          <CardDescription>Download comprehensive assessment data for analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Export all student assessment data in CSV format, including scaled scores, raw scores, and risk levels.
            </p>
            <Button onClick={handleExportCSV} className="bg-primary hover:bg-primary/90">
              Download CSV Report
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
