"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Copy, Trash2 } from "lucide-react"

interface PublicSurvey {
  id: string
  token: string
  is_active: boolean
  response_count: number
  created_at: string
  expires_at: string | null
}

export default function SurveysPage() {
  const [surveys, setSurveys] = useState<PublicSurvey[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    fetchSurveys()
  }, [])

  const fetchSurveys = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login")
        return
      }

      const schoolId = user.user_metadata?.school_id

      const { data } = await supabase
        .from("public_surveys")
        .select("*")
        .eq("school_id", schoolId)
        .order("created_at", { ascending: false })

      setSurveys(data || [])
    } catch (error) {
      console.error("Error fetching surveys:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateSurvey = async () => {
    setIsCreating(true)
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const schoolId = user.user_metadata?.school_id
      const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)

      const { error } = await supabase.from("public_surveys").insert({
        school_id: schoolId,
        token,
        created_by: user.id,
        is_active: true,
      })

      if (error) throw error
      await fetchSurveys()
    } catch (error) {
      console.error("Error creating survey:", error)
      alert("Failed to create survey")
    } finally {
      setIsCreating(false)
    }
  }

  const handleDeleteSurvey = async (surveyId: string) => {
    if (!confirm("Are you sure? Students won't be able to submit responses to this survey.")) return

    try {
      const { error } = await supabase.from("public_surveys").delete().eq("id", surveyId)
      if (error) throw error
      await fetchSurveys()
    } catch (error) {
      console.error("Error deleting survey:", error)
      alert("Failed to delete survey")
    }
  }

  const handleCopyLink = (token: string) => {
    const link = `${window.location.origin}/survey/${token}`
    navigator.clipboard.writeText(link)
    setCopied(token)
    setTimeout(() => setCopied(null), 2000)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Public Survey Links</h1>
          <p className="text-muted-foreground">
            Create shareable links for students to complete assessments anonymously
          </p>
        </div>
        <Button onClick={handleCreateSurvey} disabled={isCreating}>
          {isCreating ? "Creating..." : "+ New Survey Link"}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
          <CardDescription>Create a shareable link for anonymous student responses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ol className="space-y-2 text-sm list-decimal list-inside">
            <li>Click "New Survey Link" to generate a unique shareable link</li>
            <li>Copy the link and share via email, classroom, or QR code</li>
            <li>Students click the link and complete the Happiness Index 360° assessment</li>
            <li>Responses are automatically saved and included in your reports</li>
            <li>View results in the Reports section</li>
          </ol>
        </CardContent>
      </Card>

      {surveys.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground mb-4">No survey links created yet.</p>
            <Button onClick={handleCreateSurvey}>Create Your First Survey</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {surveys.map((survey) => (
            <Card key={survey.id}>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">Survey Link</p>
                    <div className="flex gap-2 items-center">
                      <Input
                        value={`${window.location.origin}/survey/${survey.token}`}
                        readOnly
                        className="font-mono text-sm"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopyLink(survey.token)}
                        className="flex-shrink-0"
                      >
                        {copied === survey.token ? "✓ Copied" : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Status</p>
                      <p className="text-lg font-semibold">{survey.is_active ? "Active" : "Inactive"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Responses</p>
                      <p className="text-lg font-semibold">{survey.response_count}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Created</p>
                      <p className="text-sm font-semibold">{new Date(survey.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteSurvey(survey.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
