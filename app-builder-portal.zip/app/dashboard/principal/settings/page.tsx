"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface SchoolBranding {
  logo_url?: string
  logo_alt_text?: string
  primary_color?: string
  secondary_color?: string
  accent_color?: string
  welcome_message?: string
  footer_text?: string
  school_email?: string
  school_phone?: string
  school_website?: string
  address?: string
}

export default function SchoolSettingsPage() {
  const [branding, setBranding] = useState<SchoolBranding>({
    primary_color: "#0891b2",
    secondary_color: "#f97316",
    accent_color: "#06b6d4",
  })
  const [logoPreview, setLogoPreview] = useState<string>("")
  const [isSaving, setIsSaving] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    setIsMounted(true)
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login")
        return
      }

      const schoolId = user.user_metadata?.school_id

      const { data: schoolData } = await supabase.from("schools").select("*").eq("id", schoolId).single()

      const { data: settingsData } = await supabase
        .from("school_settings")
        .select("*")
        .eq("school_id", schoolId)
        .single()

      setBranding({
        logo_url: settingsData?.logo_url,
        logo_alt_text: settingsData?.logo_alt_text,
        primary_color: settingsData?.primary_color || "#0891b2",
        secondary_color: settingsData?.secondary_color || "#f97316",
        accent_color: settingsData?.accent_color || "#06b6d4",
        welcome_message: settingsData?.welcome_message,
        footer_text: settingsData?.footer_text,
        school_email: schoolData?.school_email,
        school_phone: schoolData?.school_phone,
        school_website: schoolData?.school_website,
        address: schoolData?.address,
      })

      if (settingsData?.logo_url) {
        setLogoPreview(settingsData.logo_url)
      }
    } catch (error) {
      console.error("Error loading settings:", error)
    }
  }

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const schoolId = user.user_metadata?.school_id
      const filename = `${schoolId}/logo-${Date.now()}`

      const { data, error } = await supabase.storage.from("school-logos").upload(filename, file)

      if (error) throw error

      const { data: urlData } = supabase.storage.from("school-logos").getPublicUrl(filename)

      setLogoPreview(urlData.publicUrl)
      setBranding((prev) => ({
        ...prev,
        logo_url: urlData.publicUrl,
      }))
    } catch (error) {
      console.error("Error uploading logo:", error)
      alert("Failed to upload logo. Please try again.")
    }
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const schoolId = user.user_metadata?.school_id

      // Update school info
      await supabase
        .from("schools")
        .update({
          school_email: branding.school_email,
          school_phone: branding.school_phone,
          school_website: branding.school_website,
          address: branding.address,
          updated_at: new Date(),
        })
        .eq("id", schoolId)

      // Update school settings
      await supabase.from("school_settings").upsert({
        school_id: schoolId,
        logo_url: branding.logo_url,
        logo_alt_text: branding.logo_alt_text,
        primary_color: branding.primary_color,
        secondary_color: branding.secondary_color,
        accent_color: branding.accent_color,
        welcome_message: branding.welcome_message,
        footer_text: branding.footer_text,
        updated_at: new Date(),
      })

      alert("Settings saved successfully!")
    } catch (error) {
      console.error("Error saving settings:", error)
      alert("Failed to save settings. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  if (!isMounted) return null

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">School Settings & Branding</h1>
        <p className="text-muted-foreground">Customize your school's appearance and information</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>School Logo</CardTitle>
            <CardDescription>Upload your school logo (PNG, JPG, max 5MB)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {logoPreview && (
              <div className="relative w-48 h-48 border border-border rounded-lg overflow-hidden bg-muted">
                <img
                  src={logoPreview || "/placeholder.svg"}
                  alt="Logo preview"
                  className="w-full h-full object-contain p-4"
                />
              </div>
            )}
            <Input
              type="file"
              accept="image/png,image/jpeg"
              onChange={handleLogoUpload}
              className="cursor-pointer"
              disabled={isSaving}
            />
            <Input
              placeholder="Logo alt text (for accessibility)"
              value={branding.logo_alt_text || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, logo_alt_text: e.target.value }))}
              disabled={isSaving}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Brand Colors</CardTitle>
            <CardDescription>Customize your school's color scheme</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Primary Color</label>
              <div className="flex gap-2 items-center">
                <input
                  type="color"
                  value={branding.primary_color || "#0891b2"}
                  onChange={(e) => setBranding((prev) => ({ ...prev, primary_color: e.target.value }))}
                  disabled={isSaving}
                  className="w-12 h-10 rounded cursor-pointer"
                />
                <Input
                  value={branding.primary_color || "#0891b2"}
                  onChange={(e) => setBranding((prev) => ({ ...prev, primary_color: e.target.value }))}
                  disabled={isSaving}
                  className="font-mono"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Secondary Color</label>
              <div className="flex gap-2 items-center">
                <input
                  type="color"
                  value={branding.secondary_color || "#f97316"}
                  onChange={(e) => setBranding((prev) => ({ ...prev, secondary_color: e.target.value }))}
                  disabled={isSaving}
                  className="w-12 h-10 rounded cursor-pointer"
                />
                <Input
                  value={branding.secondary_color || "#f97316"}
                  onChange={(e) => setBranding((prev) => ({ ...prev, secondary_color: e.target.value }))}
                  disabled={isSaving}
                  className="font-mono"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>School Information</CardTitle>
            <CardDescription>Basic information about your school</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="School email"
              value={branding.school_email || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, school_email: e.target.value }))}
              disabled={isSaving}
            />
            <Input
              placeholder="School phone"
              value={branding.school_phone || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, school_phone: e.target.value }))}
              disabled={isSaving}
            />
            <Input
              placeholder="School website"
              value={branding.school_website || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, school_website: e.target.value }))}
              disabled={isSaving}
            />
            <Input
              placeholder="School address"
              value={branding.address || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, address: e.target.value }))}
              disabled={isSaving}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Custom Messages</CardTitle>
            <CardDescription>Welcome and footer messages</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Welcome message (shown on assessment page)"
              value={branding.welcome_message || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, welcome_message: e.target.value }))}
              disabled={isSaving}
              rows={3}
            />
            <Textarea
              placeholder="Footer text"
              value={branding.footer_text || ""}
              onChange={(e) => setBranding((prev) => ({ ...prev, footer_text: e.target.value }))}
              disabled={isSaving}
              rows={2}
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Button onClick={handleSave} disabled={isSaving} className="w-full md:w-auto">
            {isSaving ? "Saving..." : "Save Settings"}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
