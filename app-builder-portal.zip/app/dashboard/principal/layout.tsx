"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function PrincipalLayout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user || (user.user_metadata?.role !== "principal" && user.user_metadata?.role !== "admin")) {
        router.push("/auth/login")
      } else {
        setUser(user)
      }
      setIsLoading(false)
    }
    checkAuth()
  }, [router, supabase])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link href="/dashboard/principal">
            <h1 className="text-2xl font-bold text-primary">MindWell</h1>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/dashboard/principal">
              <Button variant="ghost">Overview</Button>
            </Link>
            <Link href="/dashboard/principal/classes">
              <Button variant="ghost">Classes</Button>
            </Link>
            <Link href="/dashboard/principal/students">
              <Button variant="ghost">Students</Button>
            </Link>
            <Link href="/dashboard/principal/reports">
              <Button variant="ghost">Reports</Button>
            </Link>
            <Link href="/dashboard/principal/alerts">
              <Button variant="ghost">Alerts</Button>
            </Link>
            <Button
              variant="outline"
              onClick={async () => {
                await supabase.auth.signOut()
                router.push("/auth/login")
              }}
            >
              Sign Out
            </Button>
          </nav>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{children}</main>
    </div>
  )
}
