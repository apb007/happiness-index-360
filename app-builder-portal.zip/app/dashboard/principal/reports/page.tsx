"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function ReportsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [reportStats, setReportStats] = useState<any>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchReportData = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        const schoolId = user.user_metadata?.school_id

        // Fetch comprehensive report data
        const { data: assessments } = await supabase
          .from("assessments")
          .select("score, risk_level, created_at")
          .eq("school_id", schoolId || "")

        const { data: classes } = await supabase.from("classes").select("id")

        const totalAssessments = assessments?.length || 0
        const avgScore = assessments?.length
          ? (assessments.reduce((sum: number, a: any) => sum + a.score, 0) / assessments.length).toFixed(1)
          : 0

        setReportStats({
          totalAssessments,
          avgScore,
          classCount: classes?.length || 0,
          assessmentTrend: assessments?.length > 0 ? "Increasing" : "No data",
        })
      } catch (error) {
        console.error("Error fetching report data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchReportData()
  }, [router, supabase])

  const handleExportCSV = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const schoolId = user.user_metadata?.school_id

      const { data: assessments } = await supabase
        .from("assessments")
        .select("student_id, score, risk_level, created_at")
        .eq("school_id", schoolId || "")

      // Create CSV content
      const headers = ["Student ID", "Score", "Risk Level", "Date"]
      const rows = assessments?.map((a: any) => [a.student_id, a.score, a.risk_level, a.created_at]) || []

      const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n")

      // Download
      const element = document.createElement("a")
      element.setAttribute("href", `data:text/csv;charset=utf-8,${encodeURIComponent(csvContent)}`)
      element.setAttribute("download", `mental-health-report-${new Date().toISOString().slice(0, 10)}.csv`)
      element.style.display = "none"
      document.body.appendChild(element)
      element.click()
      document.body.removeChild(element)
    } catch (error) {
      console.error("Error exporting CSV:", error)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Reports</h1>
        <p className="text-muted-foreground">Generate and export comprehensive assessment reports</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Assessments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{reportStats?.totalAssessments || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Average Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{reportStats?.avgScore || "0"}%</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Classes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{reportStats?.classCount || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm font-medium text-primary">{reportStats?.assessmentTrend}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Export Data</CardTitle>
          <CardDescription>Download comprehensive assessment data for further analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Export all assessment data in CSV format for use in spreadsheet applications or data analysis tools.
            </p>
            <Button onClick={handleExportCSV} className="bg-primary hover:bg-primary/90">
              Download CSV Report
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Compliance & Privacy</CardTitle>
          <CardDescription>Information about data handling and compliance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm text-muted-foreground">
            <p>
              All student assessment data is stored securely and complies with FERPA (Family Educational Rights and
              Privacy Act) requirements.
            </p>
            <p>Data is encrypted in transit and at rest using industry-standard security protocols.</p>
            <p>Assessments are anonymized to protect student privacy while maintaining research integrity.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
