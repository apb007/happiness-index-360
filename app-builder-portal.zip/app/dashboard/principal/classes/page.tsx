"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ClassData {
  id: string
  name: string
  grade_level: string
  teacher_id: string
  teacher_name: string
  student_count: number
  at_risk_count: number
}

export default function ClassesPage() {
  const [classes, setClasses] = useState<ClassData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        // Get all classes in school
        const { data: classesData, error: classError } = await supabase
          .from("classes")
          .select("id, name, grade_level, teacher_id")
          .order("name")

        if (classError) throw classError

        // Fetch teacher names and student counts
        const classesWithDetails = await Promise.all(
          (classesData || []).map(async (cls) => {
            const { data: teacher } = await supabase
              .from("profiles")
              .select("first_name, last_name")
              .eq("id", cls.teacher_id)
              .single()

            const { data: students } = await supabase.from("class_students").select("id").eq("class_id", cls.id)

            const studentIds = students?.map((s) => s.id) || []

            const { data: atRiskAssessments } = await supabase
              .from("assessments")
              .select("student_id")
              .in("student_id", studentIds)
              .in("risk_level", ["high", "critical"])

            return {
              ...cls,
              teacher_name: teacher ? `${teacher.first_name} ${teacher.last_name}` : "Unknown",
              student_count: students?.length || 0,
              at_risk_count: atRiskAssessments?.length || 0,
            }
          }),
        )

        setClasses(classesWithDetails)
      } catch (error) {
        console.error("Error fetching classes:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchClasses()
  }, [router, supabase])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Classes</h1>
        <p className="text-muted-foreground">Overview of all classes in your school</p>
      </div>

      {classes.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground">No classes found.</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>All Classes ({classes.length})</CardTitle>
            <CardDescription>Click on a class to view detailed information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-left">
                    <th className="pb-3 font-medium text-muted-foreground">Class Name</th>
                    <th className="pb-3 font-medium text-muted-foreground">Grade</th>
                    <th className="pb-3 font-medium text-muted-foreground">Teacher</th>
                    <th className="pb-3 font-medium text-muted-foreground">Students</th>
                    <th className="pb-3 font-medium text-muted-foreground">At Risk</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {classes.map((cls) => (
                    <tr key={cls.id} className="hover:bg-secondary/50 transition">
                      <td className="py-3 font-medium">{cls.name}</td>
                      <td className="py-3">{cls.grade_level || "-"}</td>
                      <td className="py-3">{cls.teacher_name}</td>
                      <td className="py-3">{cls.student_count}</td>
                      <td className="py-3">
                        {cls.at_risk_count > 0 ? (
                          <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-400">
                            {cls.at_risk_count}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
