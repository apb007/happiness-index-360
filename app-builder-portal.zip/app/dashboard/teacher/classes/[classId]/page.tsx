"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface StudentAssessment {
  student_id: string
  email: string
  first_name: string
  last_name: string
  latest_score?: number
  latest_risk?: string
  assessment_count: number
}

export default function ClassDetailPage() {
  const [students, setStudents] = useState<StudentAssessment[]>([])
  const [className, setClassName] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const params = useParams()
  const classId = params?.classId as string
  const supabase = createClient()

  useEffect(() => {
    const fetchClassData = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        // Fetch class info
        const { data: classData, error: classError } = await supabase
          .from("classes")
          .select("name")
          .eq("id", classId)
          .eq("teacher_id", user.id)
          .single()

        if (classError) throw classError
        setClassName(classData.name)

        // Fetch students in class with their assessments
        const { data: classStudents, error: studentError } = await supabase
          .from("class_students")
          .select("student_id")
          .eq("class_id", classId)

        if (studentError) throw studentError

        const studentIds = classStudents?.map((cs) => cs.student_id) || []

        if (studentIds.length > 0) {
          const { data: profiles } = await supabase
            .from("profiles")
            .select("id, email, first_name, last_name")
            .in("id", studentIds)

          const studentsWithAssessments = await Promise.all(
            (profiles || []).map(async (student) => {
              const { data: assessments } = await supabase
                .from("assessments")
                .select("score, risk_level, created_at")
                .eq("student_id", student.id)
                .order("created_at", { ascending: false })

              const latest = assessments?.[0]

              return {
                student_id: student.id,
                email: student.email,
                first_name: student.first_name || "",
                last_name: student.last_name || "",
                latest_score: latest?.score,
                latest_risk: latest?.risk_level,
                assessment_count: assessments?.length || 0,
              }
            }),
          )

          setStudents(
            studentsWithAssessments.sort((a, b) =>
              (a.first_name + a.last_name).localeCompare(b.first_name + b.last_name),
            ),
          )
        }
      } catch (error) {
        console.error("Error fetching class data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (classId) {
      fetchClassData()
    }
  }, [classId, router, supabase])

  const getRiskBadgeColor = (risk?: string) => {
    switch (risk) {
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-400"
      case "moderate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-400"
      case "high":
        return "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-400"
      case "critical":
        return "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-950 dark:text-gray-400"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">{className}</h1>
        <p className="text-muted-foreground">{students.length} students</p>
      </div>

      {students.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground">No students enrolled in this class yet.</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Student Assessments</CardTitle>
            <CardDescription>Latest assessment results and trends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-left">
                    <th className="pb-3 font-medium text-muted-foreground">Name</th>
                    <th className="pb-3 font-medium text-muted-foreground">Email</th>
                    <th className="pb-3 font-medium text-muted-foreground">Latest Score</th>
                    <th className="pb-3 font-medium text-muted-foreground">Risk Level</th>
                    <th className="pb-3 font-medium text-muted-foreground">Assessments</th>
                    <th className="pb-3 font-medium text-muted-foreground">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {students.map((student) => (
                    <tr key={student.student_id} className="hover:bg-secondary/50 transition">
                      <td className="py-3 font-medium">
                        {student.first_name} {student.last_name}
                      </td>
                      <td className="py-3 text-muted-foreground text-xs">{student.email}</td>
                      <td className="py-3">{student.latest_score ? `${Math.round(student.latest_score)}%` : "-"}</td>
                      <td className="py-3">
                        {student.latest_risk ? (
                          <Badge className={getRiskBadgeColor(student.latest_risk)}>
                            {student.latest_risk.charAt(0).toUpperCase() + student.latest_risk.slice(1)}
                          </Badge>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="py-3">{student.assessment_count}</td>
                      <td className="py-3">
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
