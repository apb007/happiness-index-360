"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface StudentData {
  id: string
  email: string
  first_name: string
  last_name: string
  latest_score?: number
  latest_risk?: string
  last_assessment?: string
}

export default function AllStudentsPage() {
  const [students, setStudents] = useState<StudentData[]>([])
  const [filteredStudents, setFilteredStudents] = useState<StudentData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [riskFilter, setRiskFilter] = useState<string>("all")
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        // Get all classes taught by this teacher
        const { data: teacherClasses } = await supabase.from("classes").select("id").eq("teacher_id", user.id)

        if (!teacherClasses || teacherClasses.length === 0) {
          setStudents([])
          setIsLoading(false)
          return
        }

        // Get all students in those classes
        const classIds = teacherClasses.map((c) => c.id)
        const { data: classStudents } = await supabase
          .from("class_students")
          .select("student_id")
          .in("class_id", classIds)

        const studentIds = [...new Set(classStudents?.map((cs) => cs.student_id) || [])]

        if (studentIds.length === 0) {
          setStudents([])
          setIsLoading(false)
          return
        }

        // Fetch student profiles and assessments
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, email, first_name, last_name")
          .in("id", studentIds)

        const studentsWithAssessments = await Promise.all(
          (profiles || []).map(async (student) => {
            const { data: assessments } = await supabase
              .from("assessments")
              .select("score, risk_level, created_at")
              .eq("student_id", student.id)
              .order("created_at", { ascending: false })
              .limit(1)

            const latest = assessments?.[0]

            return {
              id: student.id,
              email: student.email,
              first_name: student.first_name || "",
              last_name: student.last_name || "",
              latest_score: latest?.score,
              latest_risk: latest?.risk_level,
              last_assessment: latest?.created_at,
            }
          }),
        )

        setStudents(studentsWithAssessments)
      } catch (error) {
        console.error("Error fetching students:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchStudents()
  }, [router, supabase])

  useEffect(() => {
    let filtered = students

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (s) =>
          s.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.email.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filter by risk level
    if (riskFilter !== "all") {
      filtered = filtered.filter((s) => s.latest_risk === riskFilter)
    }

    setFilteredStudents(filtered)
  }, [searchTerm, riskFilter, students])

  const getRiskBadgeColor = (risk?: string) => {
    switch (risk) {
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-400"
      case "moderate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-400"
      case "high":
        return "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-400"
      case "critical":
        return "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-950 dark:text-gray-400"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">All Students</h1>
        <p className="text-muted-foreground">View all students across your classes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-xs">
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={riskFilter === "all" ? "default" : "outline"}
                onClick={() => setRiskFilter("all")}
                size="sm"
              >
                All
              </Button>
              <Button
                variant={riskFilter === "critical" ? "default" : "outline"}
                onClick={() => setRiskFilter("critical")}
                size="sm"
              >
                Critical
              </Button>
              <Button
                variant={riskFilter === "high" ? "default" : "outline"}
                onClick={() => setRiskFilter("high")}
                size="sm"
              >
                High
              </Button>
              <Button
                variant={riskFilter === "moderate" ? "default" : "outline"}
                onClick={() => setRiskFilter("moderate")}
                size="sm"
              >
                Moderate
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {filteredStudents.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground">
              {students.length === 0 ? "You have no students yet." : "No students match your filters."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Students ({filteredStudents.length})</CardTitle>
            <CardDescription>Click to view detailed assessment history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-left">
                    <th className="pb-3 font-medium text-muted-foreground">Name</th>
                    <th className="pb-3 font-medium text-muted-foreground">Email</th>
                    <th className="pb-3 font-medium text-muted-foreground">Latest Score</th>
                    <th className="pb-3 font-medium text-muted-foreground">Risk Level</th>
                    <th className="pb-3 font-medium text-muted-foreground">Last Assessment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredStudents.map((student) => (
                    <tr key={student.id} className="hover:bg-secondary/50 transition cursor-pointer">
                      <td className="py-3 font-medium">
                        {student.first_name} {student.last_name}
                      </td>
                      <td className="py-3 text-muted-foreground text-xs">{student.email}</td>
                      <td className="py-3">
                        {student.latest_score ? `${Math.round(student.latest_score)}%` : "No assessment"}
                      </td>
                      <td className="py-3">
                        {student.latest_risk ? (
                          <Badge className={getRiskBadgeColor(student.latest_risk)}>
                            {student.latest_risk.charAt(0).toUpperCase() + student.latest_risk.slice(1)}
                          </Badge>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="py-3 text-muted-foreground text-xs">
                        {student.last_assessment ? new Date(student.last_assessment).toLocaleDateString() : "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
