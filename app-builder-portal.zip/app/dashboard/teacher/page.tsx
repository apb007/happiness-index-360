"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface Class {
  id: string
  name: string
  grade_level: string
  description: string
  student_count?: number
  at_risk_count?: number
}

export default function TeacherDashboardPage() {
  const [classes, setClasses] = useState<Class[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/auth/login")
          return
        }

        const { data: classesData, error: classError } = await supabase
          .from("classes")
          .select("id, name, grade_level, description")
          .eq("teacher_id", user.id)
          .order("name")

        if (classError) throw classError

        // Get student counts for each class
        const classesWithCounts = await Promise.all(
          (classesData || []).map(async (cls) => {
            const { data: students } = await supabase.from("class_students").select("id").eq("class_id", cls.id)

            const { data: atRiskAssessments } = await supabase
              .from("assessments")
              .select("student_id")
              .eq("school_id", user.user_metadata?.school_id)
              .in("student_id", students?.map((s) => s.id) || [])
              .in("risk_level", ["high", "critical"])

            return {
              ...cls,
              student_count: students?.length || 0,
              at_risk_count: atRiskAssessments?.length || 0,
            }
          }),
        )

        setClasses(classesWithCounts)
      } catch (error) {
        console.error("Error fetching classes:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchClasses()
  }, [router, supabase])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Your Classes</h1>
          <p className="text-muted-foreground">Monitor student mental health across your classes</p>
        </div>
        <Button>+ Create Class</Button>
      </div>

      {classes.length === 0 ? (
        <Card>
          <CardContent className="pt-8 text-center">
            <p className="text-muted-foreground mb-4">You don't have any classes yet.</p>
            <Button>Create Your First Class</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {classes.map((cls) => (
            <Card key={cls.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle>{cls.name}</CardTitle>
                <CardDescription>{cls.grade_level && `Grade ${cls.grade_level}`}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {cls.description && <p className="text-sm text-foreground">{cls.description}</p>}

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-secondary/50 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{cls.student_count}</p>
                    <p className="text-xs text-muted-foreground">Students</p>
                  </div>
                  <div className="p-3 bg-orange-100 dark:bg-orange-950 rounded-lg">
                    <p className="text-2xl font-bold text-orange-600">{cls.at_risk_count}</p>
                    <p className="text-xs text-muted-foreground">At Risk</p>
                  </div>
                </div>

                <Link href={`/dashboard/teacher/classes/${cls.id}`}>
                  <Button className="w-full bg-transparent" variant="outline">
                    View Class
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
