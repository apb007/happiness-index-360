import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import { calculateScore, determineRiskLevel } from "@/lib/scoring"

export async function POST(request: NextRequest) {
  try {
    const { responses, surveyToken } = await request.json()

    if (!responses || !surveyToken) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const supabase = await createClient()

    // Verify survey token and get school ID
    const { data: surveyData, error: surveyError } = await supabase
      .from("public_surveys")
      .select("id, school_id")
      .eq("token", surveyToken)
      .eq("is_active", true)
      .single()

    if (surveyError || !surveyData) {
      return NextResponse.json({ error: "Invalid or expired survey token" }, { status: 401 })
    }

    // Calculate score
    const { raw, scaled } = calculateScore(responses)
    const riskLevel = determineRiskLevel(scaled)

    // Save anonymous assessment
    const { data: assessment, error: assessmentError } = await supabase.from("assessments").insert({
      student_id: null, // Anonymous
      school_id: surveyData.school_id,
      responses,
      raw_score: raw,
      score: scaled,
      risk_level: riskLevel,
      is_anonymous: true,
    })

    if (assessmentError) throw assessmentError

    return NextResponse.json({
      success: true,
      assessment: assessment?.[0],
      scaledScore: scaled,
      riskLevel,
    })
  } catch (error) {
    console.error("Survey submission error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
