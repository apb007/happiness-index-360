import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"
import { exportAssessmentsToCSV } from "@/lib/csv-export"

export async function GET() {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const schoolId = user.user_metadata?.school_id

    if (!schoolId) {
      return NextResponse.json({ error: "School ID not found" }, { status: 400 })
    }

    const csvContent = await exportAssessmentsToCSV(schoolId)

    return new NextResponse(csvContent, {
      headers: {
        "Content-Type": "text/csv;charset=utf-8",
        "Content-Disposition": `attachment; filename="happiness-index-report-${new Date().toISOString().slice(0, 10)}.csv"`,
      },
    })
  } catch (error) {
    console.error("Export error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Export failed" }, { status: 500 })
  }
}
