import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import { checkAndCreateAlerts } from "@/lib/alerts"
import { calculateScore, determineRiskLevel } from "@/lib/scoring"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { responses } = await request.json()

    if (!responses || typeof responses !== "object") {
      return NextResponse.json({ error: "Invalid responses" }, { status: 400 })
    }

    const { raw, scaled } = calculateScore(responses)
    const riskLevel = determineRiskLevel(scaled)

    // Get user's school
    const { data: profile } = await supabase.from("profiles").select("school_id").eq("id", user.id).single()

    const schoolId = profile?.school_id || user.user_metadata?.school_id

    // Save assessment with scaled score
    const { data: assessment, error: assessmentError } = await supabase.from("assessments").insert({
      student_id: user.id,
      school_id: schoolId,
      responses,
      raw_score: raw,
      score: scaled,
      risk_level: riskLevel,
    })

    if (assessmentError) throw assessmentError

    // Create alerts if necessary
    await checkAndCreateAlerts(user.id, schoolId, scaled, riskLevel)

    return NextResponse.json({
      success: true,
      assessment: assessment?.[0],
      scaledScore: scaled,
      rawScore: raw,
      riskLevel,
    })
  } catch (error) {
    console.error("Assessment submission error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
