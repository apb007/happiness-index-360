"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl text-center space-y-8">
        <div className="space-y-3">
          <h1 className="text-5xl font-bold text-foreground">MindWell</h1>
          <p className="text-xl text-muted-foreground">Mental Health Assessment Platform for High Schools</p>
        </div>

        <p className="text-lg text-foreground max-w-lg mx-auto">
          Anonymous assessments to help students, teachers, and administrators understand and support mental health in
          your school community.
        </p>

        <div className="flex gap-4 justify-center pt-8">
          <Link href="/auth/login">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              Sign In
            </Button>
          </Link>
          <Link href="/auth/sign-up">
            <Button size="lg" variant="outline">
              Create Account
            </Button>
          </Link>
        </div>

        <div className="pt-8 border-t border-border">
          <p className="text-sm text-muted-foreground mb-4">Choose your role to get started:</p>
          <div className="grid md:grid-cols-4 gap-4 mt-6">
            {[
              { title: "Student", desc: "Take assessments" },
              { title: "Teacher", desc: "Monitor class health" },
              { title: "Principal", desc: "School insights" },
              { title: "Administrator", desc: "System management" },
            ].map((role) => (
              <div key={role.title} className="p-4 rounded-lg bg-card border border-border">
                <h3 className="font-semibold text-card-foreground">{role.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{role.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
