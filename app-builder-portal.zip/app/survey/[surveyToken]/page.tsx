"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { AssessmentProgress } from "@/components/assessment-progress"

const DEFAULT_QUESTIONS = [
  { id: "1", question_text: "I often feel emotionally drained.", order: 1 },
  { id: "2", question_text: "My emotions affect my daily performance.", order: 2 },
  { id: "3", question_text: "I find it difficult to stay motivated.", order: 3 },
  { id: "4", question_text: "I overthink decisions.", order: 4 },
  { id: "5", question_text: "I worry about the future constantly.", order: 5 },
  { id: "6", question_text: "I feel anxious without a specific reason.", order: 6 },
  { id: "7", question_text: "I feel burnt out due to academics.", order: 7 },
  { id: "8", question_text: "I struggle to balance studies and personal life.", order: 8 },
  { id: "9", question_text: "I feel pressure to choose the right career.", order: 9 },
  { id: "10", question_text: "I am confident about who I am.", order: 10 },
  { id: "11", question_text: "I often question my abilities.", order: 11 },
  { id: "12", question_text: "I feel like a failure sometimes.", order: 12 },
  { id: "13", question_text: "I feel isolated even among peers.", order: 13 },
  { id: "14", question_text: "I find it hard to communicate honestly.", order: 14 },
  { id: "15", question_text: "Relationship issues affect my mental state.", order: 15 },
  { id: "16", question_text: "My phone/social media affects my well-being.", order: 16 },
  { id: "17", question_text: "I face sleep issues due to late-night device use.", order: 17 },
  { id: "18", question_text: "I experience low energy often.", order: 18 },
  { id: "19", question_text: "I know effective ways to manage stress.", order: 19 },
  { id: "20", question_text: "I feel helpless when upset.", order: 20 },
  { id: "21", question_text: "I have thoughts of harming myself.", order: 21 },
  { id: "22", question_text: "I feel like giving up when things get difficult.", order: 22 },
  { id: "23", question_text: "I feel emotionally supported at home.", order: 23 },
  { id: "24", question_text: "I feel comfortable speaking to teachers or counsellors.", order: 24 },
  { id: "25", question_text: "I fear I may not meet academic expectations.", order: 25 },
  { id: "26", question_text: "I feel uncertain about my future.", order: 26 },
  { id: "27", question_text: "I am scared of disappointing my parents.", order: 27 },
  { id: "28", question_text: "I feel confident handling challenges.", order: 28 },
  { id: "29", question_text: "I believe I can succeed.", order: 29 },
  { id: "30", question_text: "I am hopeful about the next few years.", order: 30 },
  { id: "31", question_text: "I maintain a healthy routine.", order: 31 },
  { id: "32", question_text: "I get enough sleep regularly.", order: 32 },
]

export default function PublicSurveyPage() {
  const params = useParams()
  const router = useRouter()
  const surveyToken = params.surveyToken as string
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [responses, setResponses] = useState<Record<string, number>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const questions = DEFAULT_QUESTIONS

  const handleResponse = (value: string) => {
    const questionId = questions[currentQuestion].id
    setResponses({
      ...responses,
      [questionId]: Number.parseInt(value),
    })
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = async () => {
    if (Object.keys(responses).length !== questions.length) {
      alert("Please answer all questions before submitting")
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch("/api/survey/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ responses, surveyToken }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to submit assessment")
      }

      setSubmitted(true)
      setTimeout(() => {
        router.push(`/survey/${surveyToken}/thank-you`)
      }, 1500)
    } catch (error) {
      console.error("Error submitting assessment:", error)
      setError(error instanceof Error ? error.message : "Error submitting assessment")
      setIsSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Card className="max-w-md w-full text-center">
          <CardContent className="pt-8">
            <div className="text-green-500 text-5xl mb-4">✓</div>
            <h2 className="text-2xl font-bold mb-2">Assessment Complete!</h2>
            <p className="text-muted-foreground">Redirecting to thank you page...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const question = questions[currentQuestion]
  const isAnswered = responses[question.id] !== undefined

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 py-8">
      <div className="max-w-3xl mx-auto px-4 space-y-6">
        <div className="text-center space-y-3">
          <h1 className="text-4xl font-bold">Happiness Index 360°</h1>
          <p className="text-lg text-muted-foreground">Student Happiness Assessment Platform</p>
          <p className="text-sm text-muted-foreground">
            Your responses are confidential. This assessment takes about 10 minutes.
          </p>
        </div>

        <AssessmentProgress current={currentQuestion} total={questions.length} />

        <Card className="border-2 border-border">
          <CardHeader>
            <CardTitle className="text-xl">{question.question_text}</CardTitle>
            <CardDescription>
              Select the option that best matches your experience (1 = Never, 5 = Always)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <RadioGroup value={responses[question.id]?.toString() || ""} onValueChange={handleResponse}>
              <div className="space-y-4">
                {[
                  { value: 1, label: "Never", desc: "This doesn't apply to me" },
                  { value: 2, label: "Rarely", desc: "Occasionally" },
                  { value: 3, label: "Sometimes", desc: "About half the time" },
                  { value: 4, label: "Often", desc: "Most of the time" },
                  { value: 5, label: "Always", desc: "Almost all the time" },
                ].map((option) => (
                  <label
                    key={option.value}
                    className="flex items-start space-x-3 p-3 rounded-lg border border-border hover:bg-secondary/50 cursor-pointer transition"
                  >
                    <RadioGroupItem value={option.value.toString()} id={`option-${option.value}`} className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor={`option-${option.value}`} className="font-medium cursor-pointer">
                        {option.label}
                      </Label>
                      <p className="text-sm text-muted-foreground">{option.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </RadioGroup>

            {error && <p className="text-red-600 text-sm mt-4">{error}</p>}
          </CardContent>
        </Card>

        <div className="flex gap-3 justify-between">
          <Button variant="outline" onClick={handlePrevious} disabled={currentQuestion === 0}>
            Previous
          </Button>

          {currentQuestion === questions.length - 1 ? (
            <Button onClick={handleSubmit} disabled={!isAnswered || isSubmitting} size="lg">
              {isSubmitting ? "Submitting..." : "Submit Assessment"}
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={!isAnswered}>
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
