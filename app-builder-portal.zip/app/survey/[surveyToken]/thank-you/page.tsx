import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ThankYouPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 flex items-center justify-center py-8">
      <Card className="max-w-md w-full text-center">
        <CardHeader>
          <div className="text-green-500 text-6xl mb-4 text-center">✓</div>
          <CardTitle className="text-2xl">Thank You!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Your assessment has been successfully submitted. Your responses help us understand and support student
            wellbeing better.
          </p>
          <p className="text-sm text-muted-foreground font-semibold">If you need immediate support:</p>
          <div className="space-y-2 text-sm">
            <p>
              <strong>Crisis Text Line:</strong> Text <code className="bg-secondary px-2 py-1 rounded">HOME</code> to{" "}
              <code className="bg-secondary px-2 py-1 rounded">741741</code>
            </p>
            <p>
              <strong>National Suicide Prevention:</strong> <code className="bg-secondary px-2 py-1 rounded">988</code>
            </p>
          </div>
          <div className="pt-4">
            <Link href="/">
              <Button variant="outline" className="w-full bg-transparent">
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
